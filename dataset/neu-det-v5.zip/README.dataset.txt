# My First Project > 2026-02-15 2:12pm
https://universe.roboflow.com/myproject-1pb3l/my-first-project-fcrjj

Provided by a Roboflow user
License: CC BY 4.0

